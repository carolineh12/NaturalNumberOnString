import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber2;

/**
 * JUnit test fixture for {@code NaturalNumber}'s constructors and kernel
 * methods.
 *
 * @author Riya Patel and Caroline Holland
 *
 */
public abstract class NaturalNumberTest {

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @return the new number
     * @ensures constructorTest = 0
     */
    protected abstract NaturalNumber constructorTest();

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param i
     *            {@code int} to initialize from
     * @return the new number
     * @requires i >= 0
     * @ensures constructorTest = i
     */
    protected abstract NaturalNumber constructorTest(int i);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param s
     *            {@code String} to initialize from
     * @return the new number
     * @requires there exists n: NATURAL (s = TO_STRING(n))
     * @ensures s = TO_STRING(constructorTest)
     */
    protected abstract NaturalNumber constructorTest(String s);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param n
     *            {@code NaturalNumber} to initialize from
     * @return the new number
     * @ensures constructorTest = n
     */
    protected abstract NaturalNumber constructorTest(NaturalNumber n);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @return the new number
     * @ensures constructorRef = 0
     */
    protected abstract NaturalNumber constructorRef();

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param i
     *            {@code int} to initialize from
     * @return the new number
     * @requires i >= 0
     * @ensures constructorRef = i
     */
    protected abstract NaturalNumber constructorRef(int i);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param s
     *            {@code String} to initialize from
     * @return the new number
     * @requires there exists n: NATURAL (s = TO_STRING(n))
     * @ensures s = TO_STRING(constructorRef)
     */
    protected abstract NaturalNumber constructorRef(String s);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param n
     *            {@code NaturalNumber} to initialize from
     * @return the new number
     * @ensures constructorRef = n
     */
    protected abstract NaturalNumber constructorRef(NaturalNumber n);

    /**
     * Test constructor.
     */
    @Test
    public void testConstructor() {

        NaturalNumber n = this.constructorTest();
        NaturalNumber nExpected = this.constructorRef();

        assertEquals(nExpected, n);
    }

    /**
     * Test constructorInt with parameter 4.
     */
    @Test
    public void testConstructorInt() {

        NaturalNumber n = this.constructorTest(4);
        NaturalNumber nExpected = this.constructorRef(4);

        assertEquals(nExpected, n);
    }

    /**
     * Test constructorInt with parameter 4749327.
     */
    @Test
    public void testConstructorIntLong() {

        NaturalNumber n = this.constructorTest(4749327);
        NaturalNumber nExpected = this.constructorRef(4749327);

        assertEquals(nExpected, n);
    }

    /**
     * Test constructorInt with parameter 0.
     */
    @Test
    public void testConstructorIntZero() {

        NaturalNumber n = this.constructorTest(0);
        NaturalNumber nExpected = this.constructorRef(0);

        assertEquals(nExpected, n);
    }

    /**
     * Test constructorInt with parameter max int.
     */
    @Test
    public void testConstructorIntMax() {

        NaturalNumber n = this.constructorTest(Integer.MAX_VALUE);
        NaturalNumber nExpected = this.constructorRef(Integer.MAX_VALUE);

        assertEquals(nExpected, n);
    }

    /**
     * Test constructorString with parameter String "4".
     */
    @Test
    public void testConstructorString() {

        NaturalNumber n = this.constructorTest("4");
        NaturalNumber nExpected = this.constructorRef("4");

        assertEquals(nExpected, n);
    }

    /**
     * Test constructorString with parameter String "4749327".
     */
    @Test
    public void testConstructorStringLong() {

        NaturalNumber n = this.constructorTest("4749327");
        NaturalNumber nExpected = this.constructorRef("4749327");

        assertEquals(nExpected, n);
    }

    /**
     * Test constructorString with parameter String "0".
     */
    @Test
    public void testConstructorStringZero() {

        NaturalNumber n = this.constructorTest("0");
        NaturalNumber nExpected = this.constructorRef("0");

        assertEquals(nExpected, n);
    }

    /**
     * Test constructorString with parameter String value of max int.
     */
    @Test
    public void testConstructorStringMaxInt() {

        String max = Integer.toString(Integer.MAX_VALUE);

        NaturalNumber n = this.constructorTest(max);
        NaturalNumber nExpected = this.constructorRef(max);

        assertEquals(nExpected, n);
    }

    /**
     * Test constructorNN with parameter Natural Number 4.
     */
    @Test
    public void testConstructorNN() {

        NaturalNumber x = new NaturalNumber2(4);

        NaturalNumber n = this.constructorTest(x);
        NaturalNumber nExpected = this.constructorRef(x);

        assertEquals(nExpected, n);
    }

    /**
     * Test constructorNN with parameter Natural Number 4749327.
     */
    @Test
    public void testConstructorNNLong() {

        NaturalNumber x = new NaturalNumber2(4749327);

        NaturalNumber n = this.constructorTest(x);
        NaturalNumber nExpected = this.constructorRef(x);

        assertEquals(nExpected, n);
    }

    /**
     * Test constructorNN with parameter Natural Number 0.
     */
    @Test
    public void testConstructorNNZero() {

        NaturalNumber x = new NaturalNumber2(0);

        NaturalNumber n = this.constructorTest(x);
        NaturalNumber nExpected = this.constructorRef(x);

        assertEquals(nExpected, n);
    }

    /**
     * Test constructorNN with parameter Natural Number max int.
     */
    @Test
    public void testConstructorNNMaxInt() {

        NaturalNumber max = new NaturalNumber2(Integer.MAX_VALUE);

        NaturalNumber n = this.constructorTest(max);
        NaturalNumber nExpected = this.constructorRef(max);

        assertEquals(nExpected, n);
    }

    /**
     * Test multiplyBy10 with n having an empty initialization.
     */
    @Test
    public void testMultiplyBy10Empty() {

        NaturalNumber n = this.constructorTest();
        NaturalNumber nExpected = this.constructorRef(7);

        n.multiplyBy10(7);

        assertEquals(nExpected, n);
    }

    /**
     * Test multiplyBy10 with one digit.
     */
    @Test
    public void testMultiplyBy10OneDigit() {

        NaturalNumber n = this.constructorTest(5);
        NaturalNumber nExpected = this.constructorRef(57);

        n.multiplyBy10(7);

        assertEquals(nExpected, n);
    }

    /**
     * Test multiplyBy10 with five digits.
     */
    @Test
    public void testMultiplyBy10FiveDigits() {

        NaturalNumber n = this.constructorTest(56328);
        NaturalNumber nExpected = this.constructorRef(563287);

        n.multiplyBy10(7);

        assertEquals(nExpected, n);
    }

    /**
     * Test multiplyBy10 when n = 0.
     */
    @Test
    public void testMultiplyBy10Zero() {

        NaturalNumber n = this.constructorTest(0);
        NaturalNumber nExpected = this.constructorRef(8);

        n.multiplyBy10(8);

        assertEquals(nExpected, n);
    }

    /**
     * Test multiplyBy10 when the digit to add to the end is 0.
     */
    @Test
    public void testMultiplyBy10AddZero() {

        NaturalNumber n = this.constructorTest(56328);
        NaturalNumber nExpected = this.constructorRef(563280);

        n.multiplyBy10(0);

        assertEquals(nExpected, n);
    }

    /**
     * Test divideBy10 with empty initializations.
     */
    @Test
    public void testDivideBy10Empty() {

        NaturalNumber n = this.constructorTest();
        NaturalNumber nExpected = this.constructorRef();

        int x = n.divideBy10();

        assertEquals(nExpected, n);
        assertEquals(0, x);

    }

    /**
     * Test divideBy10 with one digit.
     */
    @Test
    public void testDivideBy10OneDigit() {

        NaturalNumber n = this.constructorTest(5);
        NaturalNumber nExpected = this.constructorRef(0);

        int x = n.divideBy10();

        assertEquals(nExpected, n);
        assertEquals(5, x);
    }

    /**
     * Test divideBy10 with five digits.
     */
    @Test
    public void testDivideBy10FiveDigits() {
        NaturalNumber n = this.constructorTest(56328);
        NaturalNumber nExpected = this.constructorRef(5632);

        int x = n.divideBy10();

        assertEquals(nExpected, n);
        assertEquals(8, x);
    }

    /**
     * Test divideBy10 when n = 0.
     */
    @Test
    public void testDivideBy10Zero() {

        NaturalNumber n = this.constructorTest(0);
        NaturalNumber nExpected = this.constructorRef(0);

        int x = n.divideBy10();

        assertEquals(nExpected, n);
        assertEquals(0, x);
    }

    /**
     * Test isZero when the NN is zero.
     */
    @Test
    public void testisZeroTrue() {
        NaturalNumber n = this.constructorTest(0);

        boolean result = n.isZero();

        assertEquals(true, result);
    }

    /**
     * Test isZero when the NN is not zero.
     */
    @Test
    public void testisZeroFalse() {
        NaturalNumber n = this.constructorTest(5);

        boolean result = n.isZero();

        assertEquals(false, result);
    }
}
